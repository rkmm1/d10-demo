<?php
/**
 * Php version 8.1.2
 *
 * @category Desc
 * @package  Package_Desc
 * @author   Display Name <username@example.com>
 * @license  My license
 * @link     sldfjsdlkfj
 */

/** // phpcs:ignore
 *
 * @file
 * Description: jhgjhgjg of what this module (or file) is doing.
 */

// /**
//  * Implements hook_help().
//  */
// function yourmodule_help($path, $arg) {
//   // or any other hook...
// }

use Drupal\contact\Entity\ContactForm;

// function demo_post_update_change_contactus_reply() // phpcs:ignore
// {
//     // // $contact_form = ContactForm::load('contactus');
//     $contact_form = ContactForm::load('contactusdemo');
//     // // $contact_form->setReply(t('Thank you for contacting us, we will reply shortly. You can call us'));
//     // // $contact_form->setReply(t('Thank you for contacting
//     // // us, we will reply shortly'));

//     $contact_form->setReply(t('post update reply test'));

//     $contact_form->save();


// }
