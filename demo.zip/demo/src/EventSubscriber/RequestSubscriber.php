<?php

namespace Drupal\demo\EventSubscriber;

use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Template File Doc Comment
 *
 * PHP version 8.2
 *
 * @category Template_Class
 * @package  Template_Class
 * @author   Author <author@domain.com>
 * @license  https://opensource.org/licenses/MIT MIT License
 * @link     http://localhost/
 */
class RequestSubscriber implements EventSubscriberInterface
{


    /**
     * {@inheritdoc}
     *
     * @return mixed
     */
    public static function getSubscribedEvents()
    {
        return [
        RequestEvent::class => ['doAnonymousRedirect',28],
        ];
    }

    /** // phpcs:ignore
     * Redirects all anonymous users to the login page.
     *
     * @param \Symfony\Component\HttpKernel\Event\RequestEvent $event The event.
     *
     * @return mixed
     */
    public function doAnonymousRedirect(RequestEvent $event)
    {
        echo "Test";

        // Make sure we are not on the user login route.
        if (\Drupal::routeMatch()->getRouteName() ==   'user.login') {
            return;
        }

        // Check if the current user is logged in.
        if (\Drupal::currentUser()->isAnonymous()) {
            // If they are not logged in, create a redirect response.
            // $url = \Drupal\mymodule\EventSubscriber\Url::fromRoute('user.login')->toString();
            $url = Url::fromRoute('user.login')->toString();
            dump($url);
            echo "URL IS " .$url;
            $redirect = new RedirectResponse($url);
            // Set the redirect response on the event, canceling default response.
            $event->setResponse($redirect);
        }
    }
}
